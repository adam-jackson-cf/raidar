Complete the smoke task exactly as requested.
Run required verification commands.
Do not make unrelated changes.
