export default function Home() {
	return (
		<main className="min-h-screen">
			<h1>Harbor smoke test ready</h1>
		</main>
	);
}
