import { render, screen } from "@testing-library/react";
import { expect, test } from "vitest";
import Home from "./page";

test("renders smoke test text", () => {
	render(<Home />);
	const element = screen.getByText(/Harbor smoke test ready/i);
	expect(element).toBeInTheDocument();
});
