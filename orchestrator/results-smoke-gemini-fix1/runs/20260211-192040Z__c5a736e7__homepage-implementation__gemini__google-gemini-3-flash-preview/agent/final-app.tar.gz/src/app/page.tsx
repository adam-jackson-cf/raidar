export default function Home() {
  return (
    <main className="min-h-screen">
      <h1>Homepage placeholder - implement the design</h1>
    </main>
  );
}
