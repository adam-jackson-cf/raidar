export default function Home() {
  return "Harbor smoke test ready";
}
