Complete the user prompt.
Run only the required verification commands.
