export default function Home() {
  return (
    <main>
      Harbor smoke test ready
    </main>
  );
}
