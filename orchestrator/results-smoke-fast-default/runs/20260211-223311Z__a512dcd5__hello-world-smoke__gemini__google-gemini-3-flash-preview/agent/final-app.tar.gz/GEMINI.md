Complete the user prompt.
