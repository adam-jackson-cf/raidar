export default function Home() {
	return <main className="min-h-screen">Harbor smoke test ready</main>;
}
